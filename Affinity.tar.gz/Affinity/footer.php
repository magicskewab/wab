<?php if (!defined('__TYPECHO_ROOT_DIR__')) exit; ?>

</section class="section-content" id="content" role="main">
     
    </section>
<?php $this->footer(); ?>
</body>
</html>
